//
//  NotesManager.swift
//  Notes
//
//  Created by User on 28/04/24.
//

import Foundation
import CoreData

class NotesManager{
    private var notesList: [Notes] = []
    private var context : NSManagedObjectContext
    
    init(context : NSManagedObjectContext){
        self.context = context
    }
    
    func fetch(){
        do{
            self.notesList = try self.context.fetch(Notes.fetchRequest())
        }
        catch let error{
            print("error: ", error)
        }

    }
    
    func countNotes() -> Int {
        return notesList.count
    }
    
    
    func createNote(title: String, uuid : UUID, desc : String, date : Date) -> Notes?{
        let newNotes = Notes(context: context)
        newNotes.title = title
        newNotes.id = UUID()
        newNotes.desc = desc
        newNotes.date = date
        
        do{
            try context.save()
            return newNotes
        }
        catch let error {
            print("Error: ", error)
            return nil
        }
    }
    
    func getAllNotes() -> [Notes]{
        if let notesList = try? self.context.fetch(Notes.fetchRequest()){
            return notesList
        }
        else{
            return []
        }
    }
    
    func getNoteByID(uuid: UUID) -> Notes?{
        let fetchRequest = NSFetchRequest<Notes>(entityName: "Notes")
        var predicate : NSPredicate?
        
        predicate  = NSPredicate(format: "id = %@", uuid as CVarArg)
        
        fetchRequest.predicate = predicate
        
        do{
            let note = try context.fetch(fetchRequest)
            return note.first
        }
        catch let error {
            print("error: ", error)
            return nil
        }
    }
    
    func updateNote(note: Notes, title: String, uuid : UUID, desc : String, date : Date) -> Notes{
        note.title = title
        note.id = UUID()
        note.desc = desc
        note.date = date
        
        do{
            try context.save()
        }
        catch let error{
            print("Error: ", error)
        }
        
        return note
        
    }
    
    func deleteNote(note : Notes) -> Bool{
        
        self.context.delete(note)
        
        do{
            try context.save()
            return true
        }
        catch let error{
            print("Error: ", error)
            return false
        }
    }
    
    
}
