//
//  NoteCell.swift
//  Notes
//
//  Created by User on 28/04/24.
//

import UIKit

class NoteCell: UITableViewCell{
    
    @IBOutlet weak var noteTitle: UILabel!
    
    @IBOutlet weak var noteContent: UILabel!
    
    
    
    override func awakeFromNib() {
        super.awakeFromNib()
    }
    
    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
    }
    
}
