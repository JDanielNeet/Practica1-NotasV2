//
//  Notes+CoreDataClass.swift
//  Notes
//
//  Created by User on 28/04/24.
//
//

import Foundation
import CoreData

@objc(Notes)
public class Notes: NSManagedObject {

}
